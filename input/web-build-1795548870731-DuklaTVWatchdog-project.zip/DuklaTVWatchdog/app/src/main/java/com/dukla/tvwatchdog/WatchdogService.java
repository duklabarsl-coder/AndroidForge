package com.dukla.tvwatchdog;

import android.app.AppOpsManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

public class WatchdogService extends Service {
    private static final String TAG = "DuklaWatchdog";
    private static final String CHANNEL = "dukla_watchdog";
    private static final String FULLY = "de.ozerov.fully";
    private static final long INTERVAL_MS = 20_000L;
    private static final long COOLDOWN_MS = 45_000L;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long lastLaunch = 0;

    private final Runnable check = new Runnable() {
        @Override public void run() {
            try { checkForeground(); }
            catch (Exception e) { Log.e(TAG, "Foreground check failed", e); }
            handler.postDelayed(this, INTERVAL_MS);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(41, buildNotification());
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        handler.removeCallbacks(check);
        handler.post(check);
        return START_STICKY;
    }

    private void checkForeground() {
        AppOpsManager ops = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
        int mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(), getPackageName());
        if (mode != AppOpsManager.MODE_ALLOWED) {
            Log.w(TAG, "Usage access is not granted");
            return;
        }

        String foreground = findForegroundPackage();
        if (foreground == null || FULLY.equals(foreground)) return;

        long now = System.currentTimeMillis();
        if (now - lastLaunch < COOLDOWN_MS) return;

        Intent launch = getPackageManager().getLaunchIntentForPackage(FULLY);
        if (launch == null) {
            Log.e(TAG, "Fully Kiosk launch intent not found");
            return;
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        try {
            startActivity(launch);
            lastLaunch = now;
            Log.i(TAG, "Returned Fully to foreground; previous package=" + foreground);
        } catch (Exception e) {
            Log.e(TAG, "Could not bring Fully to foreground", e);
        }
    }

    private String findForegroundPackage() {
        UsageStatsManager usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
        long now = System.currentTimeMillis();
        UsageEvents events = usm.queryEvents(now - 120_000L, now);
        UsageEvents.Event event = new UsageEvents.Event();
        String current = null;
        long latest = 0;
        while (events != null && events.hasNextEvent()) {
            events.getNextEvent(event);
            int type = event.getEventType();
            if (type == UsageEvents.Event.MOVE_TO_FOREGROUND ||
                    (Build.VERSION.SDK_INT >= 29 && type == 23)) {
                if (event.getTimeStamp() >= latest) {
                    latest = event.getTimeStamp();
                    current = event.getPackageName();
                }
            }
        }
        return current;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL,
                    "Dukla TV Watchdog", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Stráži, aby Fully Kiosk zostal otvorený");
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        int flags = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, flags);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setContentTitle("Dukla TV Watchdog")
                .setContentText("Kontrola Fully Kiosk každých 20 sekúnd")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentIntent(pi).setOngoing(true).build();
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(check);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
