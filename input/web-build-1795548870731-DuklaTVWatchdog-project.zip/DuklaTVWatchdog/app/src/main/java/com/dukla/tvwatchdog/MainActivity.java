package com.dukla.tvwatchdog;

import android.app.Activity;
import android.app.AppOpsManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 24, 28, 24);
        root.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("DUKLA TV WATCHDOG");
        title.setTextSize(24);
        title.setTextColor(0xFF007F8B);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("Kontroluje, či je Fully Kiosk v popredí. Ak Fire TV zobrazí inú aplikáciu, pokúsi sa znovu otvoriť Fully.");
        info.setTextSize(16);
        info.setPadding(0, 18, 0, 18);
        root.addView(info);

        status = new TextView(this);
        status.setTextSize(15);
        status.setPadding(0, 8, 0, 18);
        root.addView(status);

        Button usage = new Button(this);
        usage.setText("Povoliť prístup k údajom o používaní");
        usage.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)));
        root.addView(usage);

        Button start = new Button(this);
        start.setText("Spustiť watchdog");
        start.setOnClickListener(v -> {
            getPreferences(MODE_PRIVATE).edit().putBoolean("enabled", true).apply();
            startWatchdog();
            refreshStatus();
        });
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("Zastaviť watchdog");
        stop.setOnClickListener(v -> {
            getPreferences(MODE_PRIVATE).edit().putBoolean("enabled", false).apply();
            stopService(new Intent(this, WatchdogService.class));
            refreshStatus();
        });
        root.addView(stop);

        setContentView(root);
        refreshStatus();
    }

    @Override protected void onResume() { super.onResume(); refreshStatus(); }

    private void startWatchdog() {
        Intent i = new Intent(this, WatchdogService.class);
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }

    private void refreshStatus() {
        boolean granted = false;
        try {
            AppOpsManager ops = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
            int mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(), getPackageName());
            granted = mode == AppOpsManager.MODE_ALLOWED;
        } catch (Exception ignored) {}
        boolean enabled = getPreferences(MODE_PRIVATE).getBoolean("enabled", false);
        status.setText("Prístup k Usage Stats: " + (granted ? "POVOLENÝ" : "NEPOVOLENÝ")
                + "\nWatchdog: " + (enabled ? "ZAPNUTÝ" : "VYPNUTÝ")
                + "\nKontrolný interval: 20 sekúnd\nCieľová aplikácia: Fully Kiosk (de.ozerov.fully)");
    }
}
