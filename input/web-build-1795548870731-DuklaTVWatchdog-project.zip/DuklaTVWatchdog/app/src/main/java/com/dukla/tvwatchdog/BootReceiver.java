package com.dukla.tvwatchdog;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (context.getSharedPreferences("MainActivity", Context.MODE_PRIVATE)
                .getBoolean("enabled", false)) {
            Intent service = new Intent(context, WatchdogService.class);
            if (android.os.Build.VERSION.SDK_INT >= 26) context.startForegroundService(service);
            else context.startService(service);
        }
    }
}
