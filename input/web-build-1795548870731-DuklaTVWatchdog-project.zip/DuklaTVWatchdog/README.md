# Dukla TV Watchdog (Android Studio project)

Small Android app intended for the first-generation Fire TV Stick 4K / AFTMM (reported Android 7.1.2, SDK 25). It checks the foreground package every 20 seconds and tries to bring Fully Kiosk Browser (`de.ozerov.fully`) back to the foreground if another app (for example Amazon Home) is on top.

## Build APK

1. Open this folder in Android Studio.
2. Let Android Studio install the Android Gradle Plugin and Android SDK Platform 35 if requested.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Install on Fire TV

Install the APK using your existing ADB connection from Windows:

```cmd
adb connect 192.168.0.252:5555
adb install -r app-debug.apk
adb shell appops set com.dukla.tvwatchdog GET_USAGE_STATS allow
```

Then open **Dukla TV Watchdog** on the Fire TV, tap **Spustiť watchdog**. Check that the app reports Usage Stats as allowed. The app stores the enabled state and tries to start its service after BOOT_COMPLETED.

## Notes / limitations

- Fully Kiosk must already be installed and its package must remain `de.ozerov.fully`.
- This app is not a replacement for Fully Kiosk and does not change the Amazon launcher.
- Android/Fire OS can still restrict background services or activity launches. This is a best-effort watchdog, not a guarantee. Test it on the actual Fire TV before relying on it overnight.
- The app uses Usage Access to identify the foreground package. The ADB `appops` command above grants that access without needing to find the Usage Access screen in Fire OS.
- It does not require Fully PLUS. It does not interact with Fully's PLUS-only JavaScript Interface, Regain Focus Timer, or Background Timer.
- The app currently targets API 28 and has minSdk 23; it is designed for the reported AFTMM / SDK 25 device.
